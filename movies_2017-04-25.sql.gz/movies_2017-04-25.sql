# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.38)
# Database: movies
# Generation Time: 2017-04-26 05:41:32 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table actor
# ------------------------------------------------------------

DROP TABLE IF EXISTS `actor`;

CREATE TABLE `actor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;

INSERT INTO `actor` (`id`, `first_name`, `last_name`)
VALUES
	(1,'Al','Pacino'),
	(2,'Marlon','Brando'),
	(3,'James','Caan'),
	(4,'Michelle','Pfeiffer'),
	(5,'Heath','Ledger'),
	(6,'Christian','Bale'),
	(7,'Aaron','Eckhart');

/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table movie
# ------------------------------------------------------------

DROP TABLE IF EXISTS `movie`;

CREATE TABLE `movie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title_index` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;

INSERT INTO `movie` (`id`, `title`, `year`)
VALUES
	(1,'The Godfather',1972),
	(2,'Scarface',1983),
	(3,'The Dark Knight',2008);

/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table movie_actors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `movie_actors`;

CREATE TABLE `movie_actors` (
  `movie_id` int(11) NOT NULL,
  `actor_id` int(11) NOT NULL,
  PRIMARY KEY (`movie_id`,`actor_id`),
  KEY `IDX_26EC6D908F93B6FC` (`movie_id`),
  KEY `IDX_26EC6D9010DAF24A` (`actor_id`),
  CONSTRAINT `FK_26EC6D9010DAF24A` FOREIGN KEY (`actor_id`) REFERENCES `actor` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_26EC6D908F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `movie_actors` WRITE;
/*!40000 ALTER TABLE `movie_actors` DISABLE KEYS */;

INSERT INTO `movie_actors` (`movie_id`, `actor_id`)
VALUES
	(1,1),
	(1,2),
	(1,3),
	(2,1),
	(2,4),
	(3,5),
	(3,6),
	(3,7);

/*!40000 ALTER TABLE `movie_actors` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table rating
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rating`;

CREATE TABLE `rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `rating` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rating_unique` (`user_id`,`movie_id`),
  KEY `IDX_D8892622A76ED395` (`user_id`),
  KEY `IDX_D88926228F93B6FC` (`movie_id`),
  CONSTRAINT `FK_D88926228F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`),
  CONSTRAINT `FK_D8892622A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;

INSERT INTO `rating` (`id`, `user_id`, `movie_id`, `rating`)
VALUES
	(1,1,1,2),
	(2,1,2,4),
	(3,1,3,7),
	(4,4,1,8),
	(5,4,2,7),
	(6,4,3,10);

/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D64992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_8D93D649A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_8D93D649C05FB297` (`confirmation_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `confirmation_token`, `password_requested_at`, `roles`)
VALUES
	(1,'Anna','anna','Anna@gmail.com','anna@gmail.com',1,'awue81o3za8k40004s0o4sg0cwgso48','$2y$13$zJ.p5cDOhF7Da8NQwyZ25uZ/wdNk1NcRi881Aw4O8pzepPSra.Z2q',NULL,NULL,NULL,'a:0:{}'),
	(2,'Beth','beth','Beth@gmail.com','beth@gmail.com',1,'24s9lm18ktb4cs4ck8wo8wkgg4c408o','$2y$13$K46o.fy.zd5s5qStkGkQleYUKZiQIce6T8yIEtpQ3WMiZpjuBaPqu',NULL,NULL,NULL,'a:0:{}'),
	(3,'Cathy','cathy','Cathy@gmail.com','cathy@gmail.com',1,'gvfdifoay2o0s80k4g080sgsww8kgg8','$2y$13$pVx6oDKOCxsq5k/4bv3Zpe7J0uNS6r0EwHf6sgsENrKO58PG/4cI2',NULL,NULL,NULL,'a:0:{}'),
	(4,'Adam','adam','Adam@gmail.com','adam@gmail.com',1,'hzadreugr1ckkgwwg08ckg00o88w4sk','$2y$13$9JQvT6YTv/nw.H5YqdZY9ehw6SIHzBF3hki7Pt1r0UDGSuNRDxeGy',NULL,NULL,NULL,'a:0:{}'),
	(5,'Ben','ben','Ben@gmail.com','ben@gmail.com',1,'6h6ga09d1wo4skookswg40s04wsswsc','$2y$13$pYSkg7pnj6fOCqm7S29wfOe8NxRgqkoz2KSe6gdSGaZKGLIwNR6nS',NULL,NULL,NULL,'a:0:{}'),
	(6,'Cam','cam','Cam@gmail.com','cam@gmail.com',1,'tu2ctf03uj4c0cg0ckowg80skccocgs','$2y$13$I/mN8GVhPFQYO1UBnOtfHOtlPVvrQlZXORkL.s52YRSuoGLMJDqOq',NULL,NULL,NULL,'a:0:{}');

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
